
/*

let amount = prompt('Amount')
let currency = prompt('Currency.')


currencyCal(amount, currency);
*/
 



/** 
  let name = prompt('Name:')
 let weight = prompt('Weight / KG')
 let height = prompt('Height / Metter.')


 getBmi(name, weight, height);

*/


/** 
  
    // 4. Age calculator.
    // ==================


 let name = prompt('Name')
 let byear = prompt('Type Your Birth-Year.')

 console.log(`

     Hi ${name}, You are ${ageCal(name, byear)} Years Old.

 `);


  
 */
 




/** 
 
   
//   A function call for calculate rectangle.
//   ======================================
 let name = prompt('What do you want to calculate? Type here.')
 let lenght = prompt('Lenght')
 let width = prompt('Width')

 rectangle(name, lenght, width)




// A function call for calculate square.
//   ======================================
  let names = prompt('What do you want to calculate? Type here.')
 let arm1 = prompt('1st Arm');
 let arm2 = prompt('2nd Arm');

 square(names, arm1, arm2);




//  A function call for calculate triangle.
//    ======================================
  let nam = prompt('What do you want to Calculate? Type here.');
 let land = prompt('Land');
 let height = prompt('Height')

 triangle(nam, land, height);


 

*/
 




 /**
  * 
  * 
  * 
  * 



   3. GPA, GRADE function for result publishing.
   =============================================


// let name = prompt('Student-Name:');
// let className = prompt('Class-Name:');
// let roll = prompt('Roll-No');

// let bn = prompt('Bangla-marks');
// let en = prompt('English-marks');
// let math = prompt('Math-marks');
// let s = prompt('Science-marks');
// let ss = prompt('Social-Science-marks');
// let rel = prompt('Religion-marks');


// console.log(`

//     Name:       ${name}
//     Class:      ${className}
//     Roll No:    ${roll}
//     ====================================================================
//     Subject         Marks            Gpa                     Grade
//     Bangla          ${bn}          ${gpaCal(bn)}          ${gradeCal(bn)}
//     English         ${en}          ${gpaCal(en)}          ${gradeCal(en)}
//     Math            ${math}        ${gpaCal(math)}        ${gradeCal(math)}
//     Science         ${s}           ${gpaCal(s)}           ${gradeCal(s)}
//     Social-Science  ${ss}          ${gpaCal(ss)}          ${gradeCal(ss)}
//     Religion        ${rel}         ${gpaCal(rel)}         ${gradeCal(rel)}


// `);




  */







 
 
 let name = prompt('Name:')
  let age = prompt('Age:')


 manDefine(name, age);
 